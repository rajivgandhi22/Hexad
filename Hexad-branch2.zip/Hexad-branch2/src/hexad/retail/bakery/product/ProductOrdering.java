package hexad.retail.bakery.product;

import java.util.List;

public class ProductOrdering {

	public void loadProductCatalog() {
		// TODO Auto-generated method stub
		
	}

	public List<SubPoductCart> selectBestPacks(String string, int i) {
		// TODO Auto-generated method stub
		return null;
	}

}
